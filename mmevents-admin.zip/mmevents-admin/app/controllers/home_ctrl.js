		/**************************** Home Controller ****************************/
app.controller("home_ctrl", function($scope,$http,$location,$modal,$rootScope) {
	
});