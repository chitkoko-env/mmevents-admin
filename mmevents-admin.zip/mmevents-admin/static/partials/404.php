<div class="container-fluid card" align="center">
	<title>404 - Page not found!</title>
	<br><br>
	<i class="fa fa-gears fa-4x" style="color:#D20000;"></i>
	<h2>Error 404 <small>Page not found!</small></h2>
	please go back or go to
	<br><br>
	<a type="button" class="btn btn-danger" href="./">Home</a>
</div>