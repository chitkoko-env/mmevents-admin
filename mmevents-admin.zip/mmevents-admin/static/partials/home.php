<div class="container-fluid card" align="center" ng-controller="home_ctrl">
	<title>Home</title>
	<h1>Welcome to MM Events System</h1>
</div>